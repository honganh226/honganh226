"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import { Calendar, MapPin, Briefcase, GraduationCap } from "lucide-react"

export function About() {
  const fadeIn = {
    hidden: { opacity: 0, y: 20 },
    visible: (i: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: 0.1 * i,
        duration: 0.5,
      },
    }),
  }

  const stats = [
    { icon: <Calendar className="h-5 w-5 text-primary" />, label: "Kinh nghiệm", value: "5+ năm" },
    { icon: <Briefcase className="h-5 w-5 text-primary" />, label: "Dự án", value: "50+" },
    { icon: <MapPin className="h-5 w-5 text-primary" />, label: "Địa điểm", value: "Hà Nội" },
    { icon: <GraduationCap className="h-5 w-5 text-primary" />, label: "Học vấn", value: "Đại học" },
  ]

  return (
    <section id="about" className="py-20 bg-muted/30">
      <div className="container px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Giới thiệu</h2>
          <div className="w-20 h-1 bg-primary mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={{
              hidden: { opacity: 0, x: -50 },
              visible: { opacity: 1, x: 0, transition: { duration: 0.6 } },
            }}
            className="relative aspect-square max-w-md mx-auto md:mx-0 rounded-lg overflow-hidden"
          >
            <Image src="/placeholder.svg?height=600&width=600" alt="About me" fill className="object-cover" />
          </motion.div>

          <div className="space-y-6">
            <motion.h3
              className="text-2xl font-bold"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              custom={0}
              variants={fadeIn}
            >
              Về tôi
            </motion.h3>

            <motion.p
              className="text-muted-foreground"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              custom={1}
              variants={fadeIn}
            >
              Tôi là một Frontend Developer với hơn 5 năm kinh nghiệm trong việc xây dựng các ứng dụng web hiện đại. Tôi
              đam mê tạo ra những trải nghiệm người dùng tuyệt vời và luôn cập nhật các công nghệ mới nhất.
            </motion.p>

            <motion.p
              className="text-muted-foreground"
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              custom={2}
              variants={fadeIn}
            >
              Tôi có kinh nghiệm làm việc với nhiều công nghệ như React, Next.js, TypeScript, Tailwind CSS và nhiều
              framework khác. Tôi cũng có kiến thức về UI/UX design và luôn đặt trải nghiệm người dùng lên hàng đầu.
            </motion.p>

            <div className="grid grid-cols-2 gap-4 pt-4">
              {stats.map((stat, index) => (
                <motion.div
                  key={index}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  custom={index + 3}
                  variants={fadeIn}
                >
                  <Card>
                    <CardContent className="p-4 flex items-center gap-3">
                      {stat.icon}
                      <div>
                        <p className="text-sm text-muted-foreground">{stat.label}</p>
                        <p className="font-medium">{stat.value}</p>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
