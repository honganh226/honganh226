"use client"

import { useRef } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { Button } from "@/components/ui/button"
import { ArrowDown } from "lucide-react"

export function Hero() {
  const scrollRef = useRef<HTMLDivElement>(null)

  const scrollToNext = () => {
    const nextSection = document.getElementById("about")
    if (nextSection) {
      nextSection.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center pt-16">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_center,rgba(var(--foreground-rgb),0.05),transparent_50%)]" />

      <div className="container px-4 py-16 md:py-24 flex flex-col md:flex-row items-center justify-between gap-12">
        <motion.div
          className="flex-1 space-y-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight">
            Xin chào, tôi là <span className="text-primary">Đoàn Hông Anh</span>
          </h1>
          <h2 className="text-2xl md:text-3xl text-muted-foreground">Tôi là sinh viên ĐH SeoulTech</h2>
          <p className="text-lg text-muted-foreground max-w-xl">
            Tôi sv năm nhất.
          </p>
          <div className="flex flex-wrap gap-4 pt-4">
            <Button size="lg">Liên hệ ngay</Button>
            <Button size="lg" variant="outline">
              Xem dự án
            </Button>
          </div>
        </motion.div>

        <motion.div
          className="flex-1 flex justify-center"
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <div className="relative w-72 h-72 md:w-96 md:h-96 rounded-full overflow-hidden border-4 border-primary/20">
            <Image src="/placeholder.svg?height=400&width=400" alt="Profile" fill className="object-cover" priority />
          </div>
        </motion.div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce">
        <Button variant="ghost" size="icon" onClick={scrollToNext} aria-label="Scroll down">
          <ArrowDown className="h-6 w-6" />
        </Button>
      </div>
    </section>
  )
}
