"use client"

import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Code, Palette, Database, Globe, Layers, GitBranch } from "lucide-react"

export function Skills() {
  const categories = [
    {
      icon: <Code className="h-6 w-6" />,
      title: "Frontend Development",
      skills: [
        { name: "HTML/CSS", level: 95 },
        { name: "JavaScript", level: 90 },
        { name: "React", level: 92 },
        { name: "Next.js", level: 88 },
        { name: "TypeScript", level: 85 },
      ],
    },
    {
      icon: <Palette className="h-6 w-6" />,
      title: "UI/UX Design",
      skills: [
        { name: "Figma", level: 90 },
        { name: "Adobe XD", level: 85 },
        { name: "Responsive Design", level: 95 },
        { name: "Wireframing", level: 88 },
      ],
    },
    {
      icon: <Database className="h-6 w-6" />,
      title: "Backend & Database",
      skills: [
        { name: "Node.js", level: 80 },
        { name: "MongoDB", level: 75 },
        { name: "Firebase", level: 85 },
        { name: "REST API", level: 90 },
      ],
    },
    {
      icon: <Layers className="h-6 w-6" />,
      title: "Frameworks & Libraries",
      skills: [
        { name: "Tailwind CSS", level: 95 },
        { name: "Material UI", level: 85 },
        { name: "Redux", level: 80 },
        { name: "GraphQL", level: 75 },
      ],
    },
    {
      icon: <GitBranch className="h-6 w-6" />,
      title: "Tools & Workflow",
      skills: [
        { name: "Git", level: 90 },
        { name: "Webpack", level: 80 },
        { name: "Jest", level: 75 },
        { name: "CI/CD", level: 70 },
      ],
    },
    {
      icon: <Globe className="h-6 w-6" />,
      title: "Languages",
      skills: [
        { name: "Tiếng Việt", level: 100 },
        { name: "Tiếng Anh", level: 85 },
        { name: "Tiếng Nhật", level: 60 },
      ],
    },
  ]

  return (
    <section id="skills" className="py-20">
      <div className="container px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Kỹ năng</h2>
          <div className="w-20 h-1 bg-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
            Những kỹ năng và công nghệ tôi đã tích lũy qua nhiều năm làm việc trong lĩnh vực phát triển web.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {categories.map((category, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="h-full">
                <CardContent className="p-6">
                  <div className="flex items-center gap-3 mb-6">
                    <div className="p-2 rounded-md bg-primary/10 text-primary">{category.icon}</div>
                    <h3 className="text-xl font-semibold">{category.title}</h3>
                  </div>

                  <div className="space-y-4">
                    {category.skills.map((skill, skillIndex) => (
                      <div key={skillIndex}>
                        <div className="flex justify-between mb-1">
                          <span className="text-sm font-medium">{skill.name}</span>
                          <span className="text-sm text-muted-foreground">{skill.level}%</span>
                        </div>
                        <Progress value={skill.level} className="h-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
