"use client"

import { useState } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Github, Maximize } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

export function Projects() {
  const [filter, setFilter] = useState("all")

  const categories = [
    { id: "all", name: "Tất cả" },
    { id: "web", name: "Web App" },
    { id: "mobile", name: "Mobile App" },
    { id: "design", name: "UI/UX" },
  ]

  const projects = [
    {
      id: 1,
      title: "E-commerce Website",
      description: "Website bán hàng với đầy đủ tính năng như giỏ hàng, thanh toán, quản lý sản phẩm.",
      image: "/placeholder.svg?height=600&width=800",
      category: "web",
      tags: ["React", "Next.js", "Tailwind CSS", "Stripe"],
      demoLink: "#",
      githubLink: "#",
    },
    {
      id: 2,
      title: "Travel App",
      description: "Ứng dụng di động giúp người dùng lên kế hoạch và đặt các chuyến du lịch.",
      image: "/placeholder.svg?height=600&width=800",
      category: "mobile",
      tags: ["React Native", "Firebase", "Google Maps API"],
      demoLink: "#",
      githubLink: "#",
    },
    {
      id: 3,
      title: "Dashboard UI Kit",
      description: "Bộ kit UI dành cho các ứng dụng dashboard với nhiều component tái sử dụng.",
      image: "/placeholder.svg?height=600&width=800",
      category: "design",
      tags: ["Figma", "UI Kit", "Design System"],
      demoLink: "#",
      githubLink: "#",
    },
    {
      id: 4,
      title: "Social Media Platform",
      description: "Nền tảng mạng xã hội với tính năng đăng bài, chat, và kết nối bạn bè.",
      image: "/placeholder.svg?height=600&width=800",
      category: "web",
      tags: ["React", "Node.js", "Socket.io", "MongoDB"],
      demoLink: "#",
      githubLink: "#",
    },
    {
      id: 5,
      title: "Fitness Tracker",
      description: "Ứng dụng theo dõi sức khỏe và luyện tập với biểu đồ thống kê.",
      image: "/placeholder.svg?height=600&width=800",
      category: "mobile",
      tags: ["React Native", "Redux", "Health API"],
      demoLink: "#",
      githubLink: "#",
    },
    {
      id: 6,
      title: "Banking App Redesign",
      description: "Thiết kế lại giao diện ứng dụng ngân hàng với trải nghiệm người dùng tốt hơn.",
      image: "/placeholder.svg?height=600&width=800",
      category: "design",
      tags: ["Adobe XD", "Prototyping", "UX Research"],
      demoLink: "#",
      githubLink: "#",
    },
  ]

  const filteredProjects = filter === "all" ? projects : projects.filter((project) => project.category === filter)

  return (
    <section id="projects" className="py-20 bg-muted/30">
      <div className="container px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">Dự án</h2>
          <div className="w-20 h-1 bg-primary mx-auto"></div>
          <p className="mt-4 text-muted-foreground max-w-2xl mx-auto">
            Một số dự án tiêu biểu tôi đã thực hiện trong quá trình làm việc.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-10">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={filter === category.id ? "default" : "outline"}
              onClick={() => setFilter(category.id)}
              className="mb-2"
            >
              {category.name}
            </Button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project, index) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              viewport={{ once: true }}
            >
              <Card className="overflow-hidden h-full flex flex-col">
                <div className="relative h-48 w-full">
                  <Image src={project.image || "/placeholder.svg"} alt={project.title} fill className="object-cover" />
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button
                        variant="secondary"
                        size="icon"
                        className="absolute top-2 right-2 bg-background/80 backdrop-blur-sm"
                      >
                        <Maximize className="h-4 w-4" />
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-4xl">
                      <DialogHeader>
                        <DialogTitle>{project.title}</DialogTitle>
                        <DialogDescription>{project.description}</DialogDescription>
                      </DialogHeader>
                      <div className="relative aspect-video w-full">
                        <Image
                          src={project.image || "/placeholder.svg"}
                          alt={project.title}
                          fill
                          className="object-cover rounded-md"
                        />
                      </div>
                      <div className="flex flex-wrap gap-2 mt-4">
                        {project.tags.map((tag, i) => (
                          <Badge key={i} variant="secondary">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </DialogContent>
                  </Dialog>
                </div>

                <CardContent className="p-6 flex-1 flex flex-col">
                  <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                  <p className="text-muted-foreground mb-4 flex-1">{project.description}</p>

                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.tags.slice(0, 3).map((tag, i) => (
                      <Badge key={i} variant="outline">
                        {tag}
                      </Badge>
                    ))}
                    {project.tags.length > 3 && <Badge variant="outline">+{project.tags.length - 3}</Badge>}
                  </div>

                  <div className="flex gap-2 mt-auto">
                    <Button variant="outline" size="sm" asChild>
                      <a
                        href={project.demoLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1"
                      >
                        <ExternalLink className="h-4 w-4" />
                        Demo
                      </a>
                    </Button>
                    <Button variant="outline" size="sm" asChild>
                      <a
                        href={project.githubLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1"
                      >
                        <Github className="h-4 w-4" />
                        Code
                      </a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
